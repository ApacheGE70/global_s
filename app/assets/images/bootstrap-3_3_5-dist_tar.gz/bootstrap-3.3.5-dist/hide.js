	function hide() 
	{
	    var x = document.getElementsByClassName("chose");
	    for (var i = 0; i < x.length; i++) {
	    	x[i].style.visibility =  'hidden';
	   	}
	   	var y = document.getElementsByClassName("notes_chose");
	    for (var i = 0; i < y.length; i++) {
	    	y[i].style.visibility =  'hidden';
	   	}
	}

	function swap() 
	{
	    var x = document.getElementsByClassName	("chose");
	    for (var i = 0; i < x.length; i++) {
	    	x[i].style.visibility =  'hidden';
	   	}
	   	var y = document.getElementsByClassName("notes_chose");
	    for (var i = 0; i < y.length; i++) {
	    	y[i].style.visibility =  'hidden';
	   	}
	}