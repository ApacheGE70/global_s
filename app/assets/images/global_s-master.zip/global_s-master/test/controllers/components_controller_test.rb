require 'test_helper'

class ComponentsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
